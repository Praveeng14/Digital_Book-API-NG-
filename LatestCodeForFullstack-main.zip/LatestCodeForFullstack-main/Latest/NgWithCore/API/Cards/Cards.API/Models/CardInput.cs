﻿namespace Cards.API.Models
{
    public class CardInput
    {
        public string cardName { get; set; }
    }
}
