﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Cards.API.Migrations
{
    public partial class dbcreated : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
