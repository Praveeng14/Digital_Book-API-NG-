export interface Card {
    id: string;
    cardholderName :string;
    cardNumber :string;
    cvc:string;
    expiryMonth:string;
    expiryYear:string;
}